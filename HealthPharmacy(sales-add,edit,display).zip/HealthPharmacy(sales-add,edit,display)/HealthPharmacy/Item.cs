﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthPharmacy
{
    class Item
    {
        private string ItemName;
        private int Quantity;
        private string Manufacturer;
        private string type;

        public Item()
        {

        }
    }
}
